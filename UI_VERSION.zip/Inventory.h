#ifndef _INVENTORY_H_
#define _INVENTORY_H_

#include <string>
#include <vector>
#include<stack>
#include<queue>
#include <fstream>
#include "Product.h"

/*
* 
* Description: This is the hearder file for Inventory, which contains vector of pointers as well as the functions required by our program.

coder: Jiangze, Junchao
*/


class manuunit // This small class is only used for find the best selling manufacturer.
{
public:
	string manuname;
	int numsold;
	manuunit(string name)
	{
		numsold=0;       
		manuname=name;
	}

};
class Inventory
{
private:

	vector<Product*>productlist;

	int _index; // This variable is used for record the position of deletion.

	void prequicksort(vector<Product*>&mylist,  int n); // This sorting function is used for sorting the data read from the file. The "sortfile" function will link it.
	void quicksort(vector<Product*>&mylist, int first, int last);

	vector<Product*> sortsold(); // This sorting function is used for sorting the number of selling. Here, we decide to use counting sort.

	vector<Product*>bestSellingProd(); // Find the best selling product(s).
	vector<manuunit>bestSellingManu();// Find the best selling manufacturer(s).
	vector<Product*>bestSellingInCate(const string&); // Find the  best selling product(s) in a given category.
	vector<Product*>bestSellingTopX(int x);// Find the Top X seling products.

public:

	Inventory();
	bool addProd(Product *); // Add product from the UI. Using insertion to insert the element into correct position. 
	bool delProd(int);// Delete a certain product.
	void addfromfile(Product*);// Add product from the file.


	vector<Product*> searchName(const string&); // Search the name of a product.
	vector<Product*> searchCategory(const string&); // Search the name of a category.


	Product* searchBarcode(int); // Using binary search for searching the barcode.

	bool saleSetter(int,int); // Set the value of selling number.
	bool stockSetter(int,int); // Set the value of stock number.

	bool batchprocess(string original, string logfile); // Batch processing. Read the original file and write it to logfile. 

	vector<Product*> reportInfo1(); // Used for reporting the best selling product.
	vector<manuunit> reportInfo2(); // Used for reporting the best selling manufacturer.
	vector<Product*> reportInfo3(const string&); // Used for reporting the best selling product in a given category. 
	vector<Product*> reportInfo4(int); // Used for reporting the Top X products.

	bool valid_input(const string&, int&); // Used for checking the validity of input.


	void sortfile(); // Used for sort the data read from the file.
	void printFile(ofstream&); // The function will link to the Query class and write the file.

	~Inventory();// Destructor. Release the dynamic memory. 
};

#endif

#include <string>
#include<cstdlib>
#include<cctype>
#include "Inventory.h"
#include "batch.h"
using namespace std;
#include<iostream>
/*
* Description: This is the implementation file of Inventory. This file contains the functionalities of our program. 
* Whenever users send the command from UI, query will send the request to file. Then, this file will get the corresponding result
and send it to the query.


coder:Jiangze
*/




Inventory::Inventory()
{

}


void Inventory::addfromfile(Product * prod)
{

	productlist.push_back(prod);

}


void Inventory::sortfile()
{
	prequicksort(productlist,(int)productlist.size());    


}


void Inventory::quicksort(vector<Product*>&mylist, int first, int last) 
{

	Product *temp;    
	int lower=first+1, upper=last;

	temp=mylist[first];
	mylist[first]=productlist[(first+last)/2];
	mylist[(first+last)/2]=temp;

	int pivot=mylist[first]->getBarcode();

	while(lower<=upper)
	{
		while(mylist[lower]->getBarcode()<pivot )
		{
			lower++;

		}
		while(pivot<mylist[upper]->getBarcode())
		{
			upper--;

		}
		if(lower<upper)
		{
			temp=mylist[lower];
			mylist[lower]=mylist[upper];
			mylist[upper]=temp;
			lower++;
			upper--;

		}
		else lower++;
	}

	temp=mylist[first];
	mylist[first]=mylist[upper];
	mylist[upper]=temp;

	if(first<upper-1)quicksort(mylist, first, upper-1);
	if(upper+1<last)quicksort(mylist,upper+1,last);

}
void Inventory::prequicksort(vector<Product*>&mylist,  int n)
{

	int i,maxindex;
	if(n<2)
		return ;
	for(i=1,maxindex=0;i<n;i++)
	{
		if(mylist[maxindex]->getBarcode()<mylist[i]->getBarcode())
			maxindex=i;
	}

	Product *temp;
	temp=mylist[n-1];
	mylist[n-1]=mylist[maxindex];
	mylist[maxindex]=temp;
	quicksort(mylist,0,(n-2));
}




bool Inventory::addProd(Product *Prod) 

{	
	int index, j,k;
	int done=0;
	if(searchBarcode(Prod->getBarcode())!=NULL)
	{

		return false;
	}
	else  
	{
		productlist.push_back(Prod);

		for(j=0;j<(int)productlist.size() && done==0;j++)
		{
			if(productlist[j]->getBarcode()>=Prod->getBarcode())
			{
				index=j;
				for(k=(int)productlist.size()-1;k>index;k--)
				{

					productlist[k]=productlist[k-1];

				}

				productlist[index]=Prod;
				done=1;
			}

		}

	}


	return true;
}



bool Inventory::delProd(int barcode) 
{

	Product*p=searchBarcode(barcode);

	if(p==NULL)
	{
		return false;
	}
	else
	{

		productlist.erase(productlist.begin()+_index);  
		return true;
	}
}



vector<Product*> Inventory::searchName(const string& str)  
{	
	vector<Product*> v;

	for(unsigned int i=0;i<productlist.size();i++)
	{
		if(str==productlist[i]->getName())
		{
			v.push_back(productlist[i]);

		}
	}
	return v;

}


vector<Product*> Inventory::searchCategory(const string& str)  
{ 
	vector<Product*> v;

	for(unsigned int i=0;i<productlist.size();i++)
	{
		if(str==productlist[i]->getCategory())
		{

			v.push_back(productlist[i]);

		}
	}


	return v;
}

Product* Inventory::searchBarcode(int barcode)   
{ 
	int start=0,mid;
	int end=(int)productlist.size()-1;

	int done=0,index;


	if(!productlist.empty())
	{

		while (start<=end && done==0)
		{
			mid=(start + end)/2;
			if(productlist[mid]->getBarcode()==barcode)
			{
				index=mid;
				done=1;
				_index=index;

			}

			else if(productlist[mid]->getBarcode()>barcode)
			{
				end =mid-1;

			}	
			else if(productlist[mid]->getBarcode()<barcode)
			{

				start=mid+1;

			}

		}

		if(done==1)  
		{
			return productlist[index];
		}
		else  return NULL;  

	}

	else return NULL;	
}


bool Inventory::saleSetter(int barcode,int num)
{ 

	Product* p;
	p=searchBarcode(barcode);
	if(p!=NULL)
	{
		if(p->updateNumSold(num))
			return true;

		else return false;
	}
	else return false;  
}


bool Inventory::stockSetter(int barcode,int num) 
{ 

	Product* p;
	p=searchBarcode(barcode);
	if(p!=NULL)
	{
		if(p->addNumStock(num))
			return true;

		else return false;
	}

	else return false;

}


vector<Product*> Inventory:: bestSellingProd()
{
	vector<Product*>v;  

	if(productlist.empty())return v;

	vector<Product*>p=sortsold();

	int max=p.back()->getNumSold();

	int j=(int)p.size()-1;

	while(p[j]->getNumSold()==max)
	{

		v.push_back(p[j]);
		j--;
	}

	return v;
}


vector<manuunit> Inventory::bestSellingManu()  
{
	int done=0;
	vector<manuunit>manulist;
	vector<manuunit>returnmanu;
	unsigned int i,j;


	for(i=0;i<productlist.size();i++)  
	{

		for(j=0;j<manulist.size() && done!=1;j++)
		{

			if(productlist[i]->getManufacturer()==manulist[j].manuname)
			{
				done=1;
				manulist[j].numsold+=productlist[i]->getNumSold();
				break;
			}
		}

		if(done==0)  
		{
			manuunit prod(productlist[i]->getManufacturer());
			prod.numsold+=productlist[i]->getNumSold(); 
			manulist.push_back(prod);

		}

		done=0;
	}
	int max=0;
	unsigned int k,p;
	for(k=0;k<manulist.size();k++)    
	{

		if(max<manulist[k].numsold)max=manulist[k].numsold; 

	}


	for(p=0;p<manulist.size();p++)  
	{

		if(max==manulist[p].numsold)returnmanu.push_back(manulist[p]);

	}

	return returnmanu;


}

vector<Product*>Inventory ::bestSellingInCate(const string& cat_name)
{
	vector<Product*> v;
	vector<Product*>return_v;
	for(unsigned int i=0;i<productlist.size();i++)  
	{
		if(productlist[i]->getCategory()==cat_name)	    
		{

			v.push_back(productlist[i]);

		}
	}
	int max=0;
	for(unsigned int i=0;i<v.size();i++)   
	{
		if(max<v[i]->getNumSold())max=v[i]->getNumSold();
	}
	for(unsigned int i=0;i<v.size();i++)  
	{
		if(max==v[i]->getNumSold())return_v.push_back(v[i]);
	}

	return return_v;
}


vector<Product*>Inventory:: bestSellingTopX(int x)  
{

	vector<Product*>p=sortsold();
	vector<Product*> return_one;
	int j;

	if(x>(int)p.size())x=(int)p.size();
	for( j=(int)p.size()-1;j>=(int)p.size()-x;j--) 
	{
		return_one.push_back(p[j]);

	}
	if(j>=0)
	{
		while(j>=0 && p[j]->getNumSold()==p[j+1]->getNumSold())
		{
			return_one.push_back(p[j]);
			j--;
		}

	}
	return return_one;
}

vector<Product*> Inventory:: sortsold() 
{

	vector<Product*>v;  
	int size=(int)productlist.size();


	if(size==0)return v;

	v.resize(size);

	int max=productlist[0]->getNumSold();
	for(unsigned int i=1;i<productlist.size();i++) 
	{

		if(max<productlist[i]->getNumSold())
			max=productlist[i]->getNumSold();

	}
	int range=max;
	int *p=new int[range+1];


	for(int i=0;i<=range;i++)
	{
		p[i]=0;
	}
	for(int i=0;i<size;i++)
	{
		p[productlist[i]->getNumSold()]++;

	}

	for(int i=1;i<=range;i++)
	{
		p[i]+=p[i-1];   
	}

	for (int i = size - 1; i >= 0; i--) 
	{
		v[p[productlist[i]->getNumSold()] - 1] = productlist[i];
		p[productlist[i]->getNumSold()]--;

	}

	delete []p;
	return v;
}

vector<Product*> Inventory::reportInfo1()
{
	return bestSellingProd();
}
vector<manuunit> Inventory:: reportInfo2()
{

	return bestSellingManu();

}
vector<Product*> Inventory::reportInfo3(const string& cat_name)
{
	return bestSellingInCate(cat_name);

}
vector<Product*> Inventory::reportInfo4(int x)
{
	return bestSellingTopX(x);	
}

bool Inventory::batchprocess(string original, string logfile) 
{	
	ifstream readFile(original);
	ofstream writeFile(logfile);
	stack<queue<Command> > transaction;

	int num_task,num_jobs,numstock,numsold;
	int barcode;
	double price;
	string blank,transactiontime,jobcommand,name,category,manufacturer;
	bool success=true;

	if(readFile.is_open())
	{	
		readFile>>num_task;


		for(int i=0;i<num_task;i++)
		{
			queue<Command>jobs;

			getline(readFile,blank);

			getline(readFile,blank);

			getline(readFile,transactiontime);

			readFile>>num_jobs;
			for(int j=0;j<num_jobs;j++)
			{
				getline(readFile,blank);

				getline(readFile,blank);

				getline(readFile,jobcommand);

				if(jobcommand=="ADD")
				{
					getline(readFile,name);
					getline(readFile,category);
					readFile>>barcode;
					readFile>>price;
					getline(readFile,blank);
					getline(readFile,manufacturer);
					readFile>>numstock;

					Command job(transactiontime,jobcommand, name,category,barcode,price,manufacturer,numstock,0);
					jobs.push(job);
				}
				else if(jobcommand=="DELETE")
				{
					readFile>>barcode;
					Command job(transactiontime,jobcommand, " "," ",barcode,0," ",0,0);
					jobs.push(job);
				}
				else if(jobcommand=="SALE")
				{
					readFile>>barcode;
					readFile>>numsold;
					Command job(transactiontime,jobcommand, " "," ",barcode,0," ",0,numsold);
					jobs.push(job);
				}
				else if (jobcommand=="RESTOCK")
				{
					readFile>>barcode;
					readFile>>numstock;
					Command job(transactiontime,jobcommand, " "," ",barcode,0," ",numstock,0);
					jobs.push(job);
				}
			}
			transaction.push(jobs);
		}

		while(!transaction.empty())
		{
			while(!transaction.top().empty())
			{
				if (transaction.top().front().getdetail()=="ADD")
				{
					name=transaction.top().front().getname();
					category=transaction.top().front().getcategory();
					manufacturer=transaction.top().front().getmanufacturer();
					barcode=transaction.top().front().getBarcode();
					numstock=transaction.top().front().getnumstock();
					price=transaction.top().front().getprice();

					Product*p=new Product (name,category,manufacturer,barcode,0,numstock,price);
					if(!addProd(p))
					{
						writeFile<<transaction.top().front().gettime()<<" "<<transaction.top().front().getdetail()<<" "<<barcode<<endl;
						delete p;

					}

					transaction.top().pop();
				}

				else if (transaction.top().front().getdetail()=="DELETE")
				{
					barcode=transaction.top().front().getBarcode();
					if(!delProd(barcode))
					{

						writeFile<<transaction.top().front().gettime()<<" "<<transaction.top().front().getdetail()<<" "<<barcode<<endl;
					}
					transaction.top().pop();	

				}

				else if (transaction.top().front().getdetail()=="SALE")
				{
					barcode=transaction.top().front().getBarcode();
					numsold=transaction.top().front().getnumsold();

					if(!saleSetter(barcode,numsold))
					{	
						writeFile<<transaction.top().front().gettime()<<" "<<transaction.top().front().getdetail()<<" "<<barcode<<endl;
					}

					transaction.top().pop();
				}
				else if (transaction.top().front().getdetail()=="RESTOCK")
				{
					barcode=transaction.top().front().getBarcode();
					numstock=transaction.top().front().getnumstock();
					if (!stockSetter(barcode,numstock))
					{
						writeFile<<transaction.top().front().gettime()<<" "<<transaction.top().front().getdetail()<<" "<<barcode<<endl;
					}
					transaction.top().pop();
				}	  


			}

			transaction.pop();
		}


		readFile.close();
		writeFile.close();

	}
	else success=false;

	return success;

}






bool Inventory::valid_input(const string& option, int& num)
{
	for(int i=0;i<int(option.size());i++)
	{
		if(!isdigit(option[i]))return false;
	}

	num=atoi(option.c_str());
	return true;
}

void Inventory::printFile(ofstream& outfile)
{
	outfile << productlist.size() << "\n" << endl;
	unsigned int i=0;
	while (i<productlist.size()){
		outfile << productlist[i]->getName() << endl;
		outfile << productlist[i]->getCategory() << endl;
		outfile << productlist[i]->getBarcode() << endl;
		outfile << productlist[i]->getPrice() << endl;
		outfile << productlist[i]->getManufacturer() << endl;
		outfile << productlist[i]->getNumSold() << endl;
		outfile << productlist[i]->getNumStock() << endl << endl;

		i++;
	}

}
Inventory::~Inventory()
{

	for(unsigned int i=0;i<productlist.size();i++)
	{
		delete productlist[i];

	}
}



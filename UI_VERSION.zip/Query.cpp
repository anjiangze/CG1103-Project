#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "Inventory.h"
#include "Product.h"
#include "Query.h"

using namespace std;

/*
*Description: This is Query implementation file. This Query file takes in charge of displaying all the information and instructions that user needed. Furthermore,
this class will take in charge of reading and writing the files. We use this class to link the UI with our inventory class.
In the Query, we build main menus as well as submenus to make users convenient. We also use functions to check whether the input is valid or not. 

* 
Coder: Nicholas, Agela
*/


int Query::cmdQuery()
{
	Inventory myInventory;
	readFile(myInventory);
	myInventory.sortfile();
	vector<Product*>receive_name;
	vector<Product*>receive_category;
	Product* get_barcode;

	int option=0;
	int barcode1;
	int numSold,numStock,num;
	double price;
	string blank, name, category, manufacturer;
	string input;


	cout << "--------------------------------------------------------------------------------"<<endl;
	cout << "|--------CEG Hypermarket Inventory Control and Monitoring System (CICMS)-------|"<<endl;
	cout << "--------------------------------------------------------------------------------"<<endl;
	cout << "1.Add a new product."<<endl;
	cout << "2.Scrap/delete a product."<<endl;
	cout << "3.Specify a sale of products."<<endl;
	cout << "4.Restock products."<<endl;
	cout << "5.Search a product by product name."<<endl;
	cout << "6.Search a product by barcode."<<endl;
	cout << "7.Search a product by category."<<endl;
	cout << "8.Batch processing."<<endl;
	cout << "9.Generate statistics." << endl;
	cout << "10.Making a backup file."<<endl;
	cout << "11.Quit."<<endl;

	while (option!=11)
	{

		while(1)
		{
			cout << "What would you like to do? [Please enter number]: ";
			getline(cin,input);
			if(myInventory.valid_input(input,option))
			{
				if(option<=0 || option>11)
					cout<<"Sorry, please choose a option in the range. "<<endl;

				else break;
			}

			else
				cout<<"Sorry, please enter a valid option."<<endl;

		}

		switch (option)
		{
		case 1:{
			cout<<endl;
			cout << "Please enter product name, category, barcode, price, manufacture,selling number,stock number: "<<endl;

			cout<<"Product's name: "<<endl;;
			getline(cin,name);
			cout<<"Product's category: "<<endl;
			getline(cin,category);

			while(1)
			{
				cout<<"Product's barcode: "<<endl;
				getline(cin, input);
				if(myInventory.valid_input(input,barcode1))
				{
					break;
				}
				else cout<<"Sorry, please enter a valid barcode number."<<endl;
			}


			cout<<"Product's price: "<<endl;
			cin>>price;
			getline(cin, blank);
			cout<<"Product's manufacturer: "<<endl;
			getline(cin,manufacturer);

			while(1)
			{
				cout<<"Product's selling number: "<<endl;
				getline(cin,input);
				if(myInventory.valid_input(input,numSold))
				{
					break;
				}
				else cout<<"Sorry, please enter a valid selling number."<<endl;
			}

			while(1)
			{
				cout<<"Product's stock number: "<<endl;
				getline(cin,input);
				if(myInventory.valid_input(input,numStock))
				{
					break;
				}
				else cout<<"Sorry, please enter a valid barcode number."<<endl;
			}


			Product *p=new Product(name,category,manufacturer,barcode1,numSold,numStock,price);

			if(myInventory.addProd(p))
			{
				cout << "Product added successfully!" << endl;
			}
			else 
			{
				cout<<"Sorry! This product has already existed!"<<endl;

			}
			break;
			   }

		case 2:{
			cout<<endl;
			while(1)
			{

				cout<<"Please enter the product's barcode: "<<endl;;

				getline(cin,input);
				if(myInventory.valid_input(input,barcode1))
				{
					break;
				}
				else cout<<"Sorry, please enter a valid barcode number."<<endl;
			}



			if(myInventory.delProd(barcode1))
			{

				cout << "Product is deleted successfully!" << endl;

			}
			else 
			{
				string op;
				cout<<"Sorry, we cannot find this product"<<endl;

				do
				{
					cout<<"Do you want to delete again? Yes or No ?(Please enter Y or N)"<<endl;  
					getline(cin,op);
					while(op!="Y" && op!="N")
					{
						cout<<"Sorry, please enter ""Y"" or ""N"" for the further implementation: "<<endl;

						getline(cin,op);
					}
					if(op=="Y")
					{

						while(1)
						{
							cout << "Please enter product barcode: "<<endl;
							getline(cin,input);
							if(myInventory.valid_input(input,barcode1))
							{
								break;
							}
							else cout<<"Sorry, please enter a valid barcode number."<<endl;
						}


						if(myInventory.delProd(barcode1))
						{
							cout << "Product is deleted successfully!" << endl;
						}   

						else 
						{
							cout<<"Sorry, we cannot find this product!"<<endl;
						}
					}
				}while (op=="Y");


			}
			break;
			   }
		case 3:
			{

				cout<<endl;
				while(1)
				{
					cout << "Please enter product barcode: "<<endl;
					getline(cin,input);
					if(myInventory.valid_input(input,barcode1))
					{
						break;
					}
					else cout<<"Sorry, please enter a valid barcode number."<<endl;
				}


				while(1)
				{
					cout << "Please enter the updating number sold: "<<endl;
					getline(cin,input);
					if(myInventory.valid_input(input,num))
					{
						break;
					}
					else cout<<"Sorry, please enter a valid selling number."<<endl;
				}

				if(myInventory.saleSetter(barcode1,num))
				{

					cout << "Sale updating successful!" << endl;

				}
				else cout<<"Sorry, the update is fail. Please make sure the barcode is correct and the product has enough stock."<<endl;

				break;
			}
		case 4:
			{

				cout<<endl;
				while(1)
				{
					cout << "Please enter product barcode: "<<endl;
					getline(cin,input);
					if(myInventory.valid_input(input,barcode1))
					{
						break;
					}
					else cout<<"Sorry, please enter a valid barcode number."<<endl;
				}


				while(1)
				{
					cout << "Please enter the updating stock number: "<<endl;
					getline(cin,input);
					if(myInventory.valid_input(input,num))
					{
						break;
					}
					else cout<<"Sorry, please enter a valid stock number."<<endl;
				}

				if	(myInventory.stockSetter(barcode1,num))
				{	
					cout << "Stock updating successful!" << endl;

				}
				else cout<<"Sorry, we cannot find this data!"<<endl;

				break;
			}
		case 5:
			{
				string op;

				cout<<endl;
				cout << "Please enter the name of the product: "<<endl;
				getline(cin,name);
				receive_name=myInventory.searchName(name);
				if(!receive_name.empty())
				{
					for(unsigned int i=0;i<receive_name.size();i++)
					{
						receive_name[i]->printAlInfo();
						cout<<endl;
					}  

					do
					{
						cout<<"Do you want to make further manipulations? (Please enter Y or N) "<<endl;
						getline(cin,op);
						while(op!="Y" && op!="N")
						{
							cout<<"Sorry, please enter ""Y"" or ""N"" for the further implementation: "<<endl;

							getline(cin,op);
						}
						if(op=="Y")
						{

							cout<<"1. Delete a certain product." <<endl;
							cout<<"2. Specifying the sale of a product."<<endl;
							cout<<"3. Restocking a product."<<endl;
							cout<<"4. Quit."<<endl; 
							cout<<"Which options do you want? "<<endl;

							while(1)
							{

								getline(cin,input);
								if(myInventory.valid_input(input,num))
								{
									break;
								}
								else cout<<"Sorry, please enter a valid number."<<endl;
							}


							switch(num)
							{
							case 1:
								{

									while(1)
									{
										cout << "Please enter product barcode: "<<endl;
										getline(cin,input);
										if(myInventory.valid_input(input,barcode1))
										{
											break;
										}
										else cout<<"Sorry, please enter a valid barcode number."<<endl;
									}



									if(myInventory.delProd(barcode1))
									{

										cout << "Product is deleted successfully!" << endl;

									}
									else
									{
										cout<<"Sorry, we cannot find this product!"<<endl;
									}
									break;
								}

							case 2:
								{

									while(1)
									{
										cout << "Please enter product barcode: "<<endl;
										getline(cin,input);
										if(myInventory.valid_input(input,barcode1))
										{
											break;
										}
										else cout<<"Sorry, please enter a valid barcode number."<<endl;
									}


									while(1)
									{
										cout << "Please enter the updating selling number: "<<endl;
										getline(cin,input);
										if(myInventory.valid_input(input,num))
										{
											break;
										}
										else cout<<"Sorry, please enter a valid selling number."<<endl;
									}
									if(myInventory.saleSetter(barcode1,num))
									{

										cout << "Sale updating successful!" << endl;

									}
									else cout<<"Sorry, update is fail. Please make sure the barcode is correct and the product has enough stock."<<endl;     


									break;
								}

							case 3:

								{

									while(1)
									{
										cout << "Please enter product barcode: "<<endl;
										getline(cin,input);
										if(myInventory.valid_input(input,barcode1))
										{
											break;
										}
										else cout<<"Sorry, please enter a valid barcode number."<<endl;
									}


									while(1)
									{
										cout << "Please enter the updating stock number: "<<endl;
										getline(cin,input);
										if(myInventory.valid_input(input,num))
										{
											break;
										}
										else cout<<"Sorry, please enter a valid stock number."<<endl;
									}

									if	(myInventory.stockSetter(barcode1,num))
									{	
										cout << "Stock updating successful!" << endl;

									}
									else cout<<"Sorry we cannot find this data!"<<endl;
									break;
								}
							case 4:
								{
									op="N";
									break;
								}
							default:
								{
									cout<<"Sorry, the option you entered is invalid."<<endl;
								}

							}


						}

					}while(op=="Y");

				}
				else cout<<"Sorry we cannot find this data!"<<endl;
				break;
			}
		case 6:
			{
				string op;
				cout<<endl;
				while(1)
				{
					cout << "Please enter product barcode: "<<endl;
					getline(cin,input);
					if(myInventory.valid_input(input,barcode1))
					{
						break;
					}
					else cout<<"Sorry, please enter a valid barcode number."<<endl;
				}

				get_barcode=myInventory.searchBarcode(barcode1);
				if(!get_barcode==NULL)

				{		
					cout<<"The product of this barcode is: "<<endl;
					get_barcode->printAlInfo();			    	

					cout<<endl;
					cout<<"Do you want to make further manipulations? (Please enter Y or N) "<<endl;
					getline(cin,op);
					while(op!="Y" && op!="N")
					{
						cout<<"Sorry, please enter ""Y"" or ""N"" for the further implementation: "<<endl;

						getline(cin,op);
					}
					if(op=="Y")
					{

						cout<<"1. Delete this product." <<endl;
						cout<<"2. Specifying the sale of a product."<<endl;
						cout<<"3. Restocking a product."<<endl;
						cout<<"4. Quit."<<endl;
						cout<<"Which options do you want? "<<endl;

						while(1)
						{

							getline(cin,input);
							if(myInventory.valid_input(input,num))
							{
								break;
							}
							else cout<<"Sorry, please enter a valid number."<<endl;
						}

						switch(num)
						{
						case 1:
							{

								myInventory.delProd(barcode1);
								cout << "Product is deleted successfully!" << endl;
								break;
							}

						case 2:
							{
								while(1)
								{
									cout << "Please enter the updating selling number: "<<endl;
									getline(cin,input);
									if(myInventory.valid_input(input,num))
									{
										break;
									}
									else cout<<"Sorry, please enter a valid selling number."<<endl;
								}
								myInventory.saleSetter(barcode1,num);
								cout << "Sale updating successful!" << endl;
								break;
							}

						case 3:

							{
								while(1)
								{
									cout << "Please enter the updating stock number: "<<endl;
									getline(cin,input);
									if(myInventory.valid_input(input,num))
									{
										break;
									}
									else cout<<"Sorry, please enter a valid stock number."<<endl;
								}


								myInventory.stockSetter(barcode1,num);

								cout << "Stock updating successful!" << endl;


								break;
							}

						case 4:
							{
								op="N";
								break;
							}
						default:
							{
								cout<<"Sorry, the option you entered is invalid."<<endl;

							}

						}

					}

				}	
				else cout<<"sorry cannot find it!"<<endl;

				break;
			}
		case 7:
			{
				cout<<endl;
				string op;

				cout << "Please enter the category of the product: "<<endl;
				getline(cin,category);


				receive_category=myInventory.searchCategory(category);
				if(!receive_category.empty())
				{
					for(unsigned int i=0;i<receive_category.size();i++)
					{
						receive_category[i]->printAlInfo();
						cout<<endl;
					}
					do
					{
						cout<<"Do you want to make further manipulations? (Please enter Y or N) "<<endl;
						getline(cin,op);
						while(op!="Y" && op!="N")
						{
							cout<<"Sorry, please enter ""Y"" or ""N"" for the further implementation: "<<endl;

							getline(cin,op);
						}
						if(op=="Y")
						{

							cout<<"1. Delete a certain product." <<endl;
							cout<<"2. Specifying the sale of a product."<<endl;
							cout<<"3. Restocking a product."<<endl;
							cout<<"4. Quit."<<endl;
							cout<<"Which options do you want? "<<endl;
							while(1)
							{

								getline(cin,input);
								if(myInventory.valid_input(input,num))
								{
									break;
								}
								else cout<<"Sorry, please enter a valid number."<<endl;
							}

							switch(num)
							{
							case 1:
								{

									while(1)
									{
										cout << "Please enter product barcode: "<<endl;
										getline(cin,input);
										if(myInventory.valid_input(input,barcode1))
										{
											break;
										}
										else cout<<"Sorry, please enter a valid barcode number."<<endl;
									}



									if(myInventory.delProd(barcode1))
									{

										cout << "Product is deleted successfully!" << endl;

									}
									else
									{
										cout<<"Sorry, we cannot find this product!"<<endl;
									}
									break;
								}

							case 2:
								{

									while(1)
									{
										cout << "Please enter product barcode: "<<endl;
										getline(cin,input);
										if(myInventory.valid_input(input,barcode1))
										{
											break;
										}
										else cout<<"Sorry, please enter a valid barcode number."<<endl;
									}


									while(1)
									{
										cout << "Please enter the selling stock number: "<<endl;
										getline(cin,input);
										if(myInventory.valid_input(input,num))
										{
											break;
										}
										else cout<<"Sorry, please enter a valid selling number."<<endl;
									}
									if(myInventory.saleSetter(barcode1,num))
									{

										cout << "Sale updating successful!" << endl;

									}
									else cout<<"Sorry, update is fail. Please make sure the barcode is correct and the product has enough stock."<<endl;     


									break;
								}

							case 3:

								{

									while(1)
									{
										cout << "Please enter product barcode: "<<endl;
										getline(cin,input);
										if(myInventory.valid_input(input,barcode1))
										{
											break;
										}
										else cout<<"Sorry, please enter a valid barcode number."<<endl;
									}


									while(1)
									{
										cout << "Please enter the updating stock number: "<<endl;
										getline(cin,input);
										if(myInventory.valid_input(input,num))
										{
											break;
										}
										else cout<<"Sorry, please enter a valid stock number."<<endl;
									}

									if	(myInventory.stockSetter(barcode1,num))
									{	
										cout << "Stock updating successful!" << endl;

									}
									else cout<<"Sorry We cannot find this data!"<<endl;
									break;
								}
							case 4:
								{
									op="N";
									break;
								}
							default:
								{
									cout<<"Sorry, the option you entered is invalid."<<endl;
								}
							}


						}

					}while(op=="Y");


				}

				else cout<<"Sorry! We cannot find it!"<<endl;
				break;
			}

		case 8:
			{
				string original,writeto;

				cout<<endl;
				cout<<"Please enter the address of the file you want to be processed: "<<endl;
				getline(cin,original);


				cout<<"Please enter the adress of the log file(which used to contain the fail cases): "<<endl;
				getline(cin,writeto);
				if(myInventory.batchprocess(original,writeto))   
				{
					cout<<"Process finish!"<<endl;
				}
				else cout<<"Sorry, we cannot find the address of the file."<<endl;
				break;
			}

		case 9:
			{
				cout<<endl;
				cout << "1.The best selling product."<<endl;
				cout << "2.The best selling manufacturer."<<endl;
				cout << "3.The best selling in a given category."<<endl;
				cout << "4.The top X best selling product."<<endl;
				cout << "5.Quit."<<endl;
				cout << "Which options do you want?"<<endl;
				while(1)
				{

					getline(cin,input);
					if(myInventory.valid_input(input,num))
					{
						break;
					}
					else cout<<"Sorry, please enter a valid number."<<endl;
				}
				switch(num)
				{
				case 1:
					{
						vector<Product*>v;
						string op;

						v=myInventory.reportInfo1();
						if(!v.empty())
						{
							cout<<"The best selling product(s) is(are): "<<endl;

							for(unsigned int i=0;i<v.size();i++)
							{
								v[i]->printAlInfo();
								cout<<endl;
							}


							do
							{
								cout<<"Do you want to make further manipulations? (Please enter Y or N)"<<endl;
								getline(cin,op);
								while(op!="Y" && op!="N")
								{
									cout<<"Sorry, please enter ""Y"" or ""N"" for the further implementation: "<<endl;

									getline(cin,op);
								}
								if(op=="Y")
								{

									cout<<"1. Delete a certain product." <<endl;
									cout<<"2. Specifying the sale of a product."<<endl;
									cout<<"3. Restocking a product."<<endl;
									cout<<"4. Quit."<<endl;
									cout<<"Which options do you want? "<<endl;

									while(1)
									{

										getline(cin,input);
										if(myInventory.valid_input(input,num))
										{
											break;
										}
										else cout<<"Sorry, please enter a valid number."<<endl;
									}

									switch(num)
									{
									case 1:
										{

											while(1)
											{
												cout << "Please enter product barcode: "<<endl;
												getline(cin,input);
												if(myInventory.valid_input(input,barcode1))
												{
													break;
												}
												else cout<<"Sorry, please enter a valid barcode number."<<endl;
											}



											if(myInventory.delProd(barcode1))
											{

												cout << "Product is deleted successfully!" << endl;

											}
											else
											{
												cout<<"Sorry, we cannot find this product!"<<endl;
											}
											break;
										}

									case 2:
										{

											while(1)
											{
												cout << "Please enter product barcode: "<<endl;
												getline(cin,input);
												if(myInventory.valid_input(input,barcode1))
												{
													break;
												}
												else cout<<"Sorry, please enter a valid barcode number."<<endl;
											}


											while(1)
											{
												cout << "Please enter the updating selling number: "<<endl;
												getline(cin,input);
												if(myInventory.valid_input(input,num))
												{
													break;
												}
												else cout<<"Sorry, please enter a valid selling number."<<endl;
											}
											if(myInventory.saleSetter(barcode1,num))
											{

												cout << "Sale updating successful!" << endl;

											}
											else cout<<"Sorry, update is fail. Please make sure the barcode is correct and the product has enough stock."<<endl;     


											break;
										}

									case 3:

										{

											while(1)
											{
												cout << "Please enter product barcode: "<<endl;
												getline(cin,input);
												if(myInventory.valid_input(input,barcode1))
												{
													break;
												}
												else cout<<"Sorry, please enter a valid barcode number."<<endl;
											}


											while(1)
											{
												cout << "Please enter the updating stock number: "<<endl;
												getline(cin,input);
												if(myInventory.valid_input(input,num))
												{
													break;
												}
												else cout<<"Sorry, please enter a valid stock number."<<endl;
											}


											if	(myInventory.stockSetter(barcode1,num))
											{	
												cout << "Stock updating successful!" << endl;

											}
											else cout<<"Sorry we cannot find this data!"<<endl;
											break;
										}
									case 4:
										{
											op="N";
											break;
										}
									default:
										{
											cout<<"Sorry, the option you entered is invalid"<<endl;
										}
									}


								}

							}while(op=="Y");
						}
						else cout<<"Sorry, the database is empty."<<endl;
						break;
					}
				case 2:
					{
						vector<manuunit>v;
						v=myInventory.reportInfo2();
						if(!v.empty())
						{
							cout<<"The best sold number is: "<<v[0].numsold<<endl;

							cout<<"The best manufacturer(s) is(are): "<<endl;
							for(unsigned int i=0;i<v.size();i++)
							{
								cout<<v[i].manuname<<endl;

							}
							cout<<endl;
						}
						else cout<<"Sorry, the database is empty."<<endl;

						break;
					}

				case 3:
					{
						vector<Product*>v;
						string catname;
						string op;

						cout<<"Please enter the category's name: "<<endl;
						cin.clear();
						getline(cin,catname);


						v=myInventory.reportInfo3(catname);

						if(v.size()==0)cout<<"Sorry! We cannot find this name in category!"<<endl;

						else 	
						{	
							cout<<"The best product(s) for "<<catname<<" is(are): "<<endl;
							for(unsigned int i=0;i<v.size();i++)
							{
								v[i]->printAlInfo();
								cout<<endl;
							}
							do
							{
								cout<<"Do you want to make further manipulations? (Please enter Y or N) "<<endl;
								getline(cin,op);
								while(op!="Y" && op!="N")
								{
									cout<<"Sorry, please enter ""Y"" or ""N"" for the further implementation: "<<endl;

									getline(cin,op);
								}
								if(op=="Y")
								{

									cout<<"1. Delete a certain product." <<endl;
									cout<<"2. Specifying the sale of a product."<<endl;
									cout<<"3. Restocking a product."<<endl;
									cout<<"4. Quit."<<endl;
									cout<<"Which options do you want? "<<endl;
									while(1)
									{

										getline(cin,input);
										if(myInventory.valid_input(input,num))
										{
											break;
										}
										else cout<<"Sorry, please enter a valid number."<<endl;
									}

									switch(num)
									{
									case 1:
										{

											while(1)
											{
												cout << "Please enter product barcode: "<<endl;
												getline(cin,input);
												if(myInventory.valid_input(input,barcode1))
												{
													break;
												}
												else cout<<"Sorry, please enter a valid barcode number."<<endl;
											}



											if(myInventory.delProd(barcode1))
											{

												cout << "Product is deleted successfully!" << endl;

											}
											else
											{
												cout<<"Sorry, we cannot find this product!"<<endl;
											}
											break;
										}

									case 2:
										{

											while(1)
											{
												cout << "Please enter product barcode: "<<endl;
												getline(cin,input);
												if(myInventory.valid_input(input,barcode1))
												{
													break;
												}
												else cout<<"Sorry, please enter a valid barcode number."<<endl;
											}


											while(1)
											{
												cout << "Please enter the updating selling number: "<<endl;
												getline(cin,input);
												if(myInventory.valid_input(input,num))
												{
													break;
												}
												else cout<<"Sorry, please enter a valid selling number."<<endl;
											}



											if(myInventory.saleSetter(barcode1,num))
											{

												cout << "Sale updating successful!" << endl;


											}
											else cout<<"Sorry we cannot find this data!"<<endl;     


											break;
										}

									case 3:

										{

											while(1)
											{
												cout << "Please enter product barcode: "<<endl;
												getline(cin,input);
												if(myInventory.valid_input(input,barcode1))
												{
													break;
												}
												else cout<<"Sorry, please enter a valid barcode number."<<endl;
											}


											while(1)
											{
												cout << "Please enter the updating stock number: "<<endl;
												getline(cin,input);
												if(myInventory.valid_input(input,num))
												{
													break;
												}
												else cout<<"Sorry, please enter a valid stock number."<<endl;
											}


											if	(myInventory.stockSetter(barcode1,num))
											{	
												cout << "Stock updating successful!" << endl;

											}
											else cout<<"Sorry we cannot find this data!"<<endl;
											break;
										}
									case 4:
										{
											op="N";
											break;
										}
									default:
										{
											cout<<"Sorry, the option you entered is invalid."<<endl;
										}
									}


								}

							}while(op=="Y");

						}
						break;		
					}
				case 4:				
					{
						vector<Product*>v;
						cout<<"please enter the TOP range you want: "<<endl;

						while(1)
						{

							getline(cin,input);
							if(myInventory.valid_input(input,num))
							{
								break;
							}
							else cout<<"Sorry, please enter a valid number."<<endl;
						}

						v=myInventory.reportInfo4(num);
						if((int)v.size()>=num)
						{
							cout<<"The top "<<num<<" products are: "<<endl;
							for(unsigned int i=0;i<v.size();i++)
							{
								v[i]->printAlInfo(); 
								cout<<endl;
							}
						}
						else if(!v.empty())
						{
							cout<<"Sorry, we do not have "<<num<<" products, the Top range for our database is: "<<endl;

							for(unsigned int i=0;i<v.size();i++)
							{
								v[i]->printAlInfo(); 
								cout<<endl;
							}
						}
						else cout<<"Sorry, the database is empty."<<endl;


						break;
					}
				case 5:
					{
						break;
					}				
				default:
					{
						cout<<"Sorry, the option you entered is invalid."<<endl;
					}
				}   
				break;			
			}

		case 10:
			{
				string address;
				cout<<endl;
				cout<<"Please enter the saving address of the file: "<<endl;
				getline(cin,address);
				outFile(myInventory,address);

				cout<<"Process finish!"<<endl;
				break;
			}


		case 11:
			{
				string address;
				string op;
				cout<<endl;
				cout<<"Do you want to save the file before leaving? (Please enter Y or N)"<<endl;
				getline(cin,op);


				while(op!="Y" && op!="N")
				{
					cout<<"Sorry, please enter ""Y"" or ""N"" for the further implementation: "<<endl;

					getline(cin,op);
				}
				if(op=="Y")
				{

					cout<<"Please enter the saving address of the file: "<<endl;
					getline(cin,address);
					outFile(myInventory,address);

					cout<<"Process finish!"<<endl;
				}
				cout << "Thank you for using our program!" << endl;
				cout << "Have a nice day!" << endl;
				exit(1);

			}
		default:
			{

				cout << "\n\nWrong command! Please try again :). \n\n" << endl;
				break;
			}
		}

		cout<<"Do you want to continue using this software?  (Please enter Y or N) "<<endl;
		cin.clear();
		string ans;
		string op;
		string address;
		getline(cin,ans);
		while(ans!="Y" && ans!="N")
		{
			cout<<"Sorry, please enter ""Y"" or ""N"" for the further implementation: "<<endl;

			getline(cin,ans);
		}
		if(ans=="N")
		{   


			cout<<"Do you want to save the file before leaving? (Please enter Y or N)"<<endl;
			getline(cin,op);
			while(op!="Y" && op!="N")
			{
				cout<<"Sorry, please enter ""Y"" or ""N"" for the further implementation: "<<endl;

				getline(cin,op);
			}
			if(op=="Y")
			{

				cout<<"Please enter the saving address of the file: "<<endl;
				getline(cin,address);
				outFile(myInventory,address);

				cout<<"Process finish!"<<endl;
			}

			cout<<"Thanks for using this software!"<<endl;
			cout<<"Have a nice day!"<<endl;
			exit(1);
		}
		cin.clear();
		system("cls");
		cout<<endl<<endl;
		cout << "--------------------------------------------------------------------------------"<<endl;
		cout << "|--------CEG Hypermarket Inventory Control and Monitoring System (CICMS)-------|"<<endl;
		cout << "--------------------------------------------------------------------------------"<<endl;
		cout << "1.Add a new product."<<endl;
		cout << "2.Scrap/delete a product."<<endl;
		cout << "3.Specify a sale of products."<<endl;
		cout << "4.Restock products."<<endl;
		cout << "5.Search a product by product name."<<endl;
		cout << "6.Search a product by barcode."<<endl;
		cout << "7.Search a product by category."<<endl;
		cout << "8.Batch processing."<<endl;
		cout << "9.Generate statistics" << endl;
		cout << "10.Making a backup file."<<endl;
		cout << "11.Quit"<<endl;

	}
	return 0;	
}


void Query::readFile(Inventory& inv)
{
	int numLines;
	string op,fileaddress,name,categ,manu,blank,input;
	int numStock,numSold,barcode;
	double price;
	ifstream fin;
	cout<<"Welcome to our software!"<<endl;
	cout<<"Before we start, do you want to read the file? (Y or N): "<<endl;
	getline(cin,op);
	while(op!="Y" && op!="N")
	{
		cout<<"Sorry, please enter ""Y"" or ""N"" for the further implementation: "<<endl;

		getline(cin,op);
	}
	do{
		if(op=="Y")
		{
			cout<<"Please enter the address of file: "<<endl;
			getline(cin,fileaddress);
			fin.open(fileaddress);
			if(fin.is_open())
			{
				fin >> numLines;
				for (int i=0;i<numLines;i++)
				{
					getline(fin,blank);
					getline(fin,blank);
					getline(fin,name);
					getline(fin,categ);
					fin>>barcode;
					fin >> price;
					getline(fin,blank);
					getline(fin,manu);
					fin>>numStock;
					fin>>numSold;
					Product*p= new Product(name,categ,manu,barcode,numSold,numStock,price);
					inv.addfromfile(p);

				}
				fin.close();
				cout << "file is loaded successfully!" << endl;
				break;
			}
			else 
			{	
				cout<<"Sorry, we cannot find the file."<<endl;
				cout<<"Do you want to load the file again? (Y or N)"<<endl;
				getline(cin,op);
				while(op!="Y" && op!="N")
				{
					cout<<"Sorry, please enter ""Y"" or ""N"" for the further implementation: "<<endl;

					getline(cin,op);
				}
			}
		}
	}while(op=="Y");
}


void Query::outFile(Inventory& inv,const string& address)
{
	ofstream outfile;
	outfile.open(address);
	inv.printFile(outfile);
	outfile.close();
}



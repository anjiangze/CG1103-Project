#ifndef _PRODUCT_H_
#define _PRODUCT_H_

#include <string>
using namespace std;

/*
* Description: This is the header file for product, which contains the attributes for our object. Besides, it contains functions that needed for this object.
* 
* Coder: Junchao, Jiangze
*/

class Product  
{
private:

	string _name;
	string _category;
	string _manufacturer;
	int _numSold,_numStock;
	int _barCode;
	double _price;

public:
	Product(string,string,string,int,int,int,double);
	string getName();
	string getCategory();
	string getManufacturer();
	int getBarcode();
	double getPrice();
	int getNumSold();
	int getNumStock();
	bool updateNumSold(int);
	bool addNumStock(int);
	bool saleSetter(int);
	bool printAlInfo();


};

#endif

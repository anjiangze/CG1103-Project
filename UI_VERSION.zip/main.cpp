#include <iostream>
#include "Inventory.h"
#include "Query.h"

/*
* Description: The main file is used for calling query.
* 
coder: Nicholas, Angela
*/

int main()
{
	Query UI;
	UI.cmdQuery();

	return 0;
}
#ifndef BATCH_H_
#define BATCH_H_
#include <string>
using namespace std;


/*
Description: This header file is used for batch processing. We define a new object called "Command", which will be used in the batch processing.

coder: Nicholas, Jiangze
*/

class Command
{
private:
	int _barcode, _numstock, _numsold;
	double _price;
	string _name, _category, _manufacturer, _detail, _time;


public:

	Command(string time, string detail, string name,string category,int barcode, double price, string manufacturer,int numstock,int numsold);
	int getBarcode();
	int getnumstock();
	int getnumsold();
	int getstockadd();
	double getprice();
	string getname();
	string getcategory();
	string getmanufacturer();
	string getdetail();
	string gettime();
};
#endif
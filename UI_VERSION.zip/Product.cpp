#include <iostream>
#include "Product.h"

using namespace std;
/*
* implemetation of product class
*
Description: This is the implementation file for the product, which is the object of this program.  It contains basic but important manipulations for our objects.

coder:Jiangze, Junchao
*/



Product::Product(string name,string category,string manufacturer,int barcode,int numSold,int numStock,double price)
{
	_name=name;  _category=category;  _manufacturer=manufacturer;  _barCode=barcode;  _numSold=numSold;
	_numStock=numStock;  _price=price;
}




string Product::getName()
{
	return _name;
}


string Product::getCategory()
{
	return _category;
}

string Product::getManufacturer()
{
	return _manufacturer;
}


int Product::getBarcode()
{
	return _barCode;
}

double Product::getPrice()
{
	return _price;
}


int Product::getNumSold()
{
	return _numSold;
}


int Product::getNumStock()
{
	return _numStock;
}


bool Product::updateNumSold(int num)
{
	if (_numStock<num)  return false;

	_numSold+=num;
	_numStock-=num;

	return true;
}


bool Product::addNumStock(int num)
{
	_numStock += num;

	return true;  
}

bool Product::saleSetter(int num)
{
	_numSold=num;

	return true;
}

bool Product::printAlInfo()
{ 
	cout << "Name: " << getName() << endl;

	cout << "Barcode: " << getBarcode() << endl;
	cout << "Categoty: "<<getCategory()<<endl;
	cout << "Manufacturer: "<<getManufacturer()<<endl;
	cout << "Price: " << getPrice() << endl;
	cout << "Number sold: "<<getNumSold()<<endl;
	cout << "Number stock: "<<getNumStock()<<endl;

	return true; 
}
#ifndef _QUERY_H_
#define _QUERY_H_
#include "Inventory.h"

/*
* Description: This class is actually dealing with UI in cmd-line UI environment
* and will also interact with inventory class and print out info
* to users, and it will handle text files too
* Coder: Jiangze
*/
class Query
{
public:
	int cmdQuery();
private:
	void outFile(Inventory& ,const string& );
	void readFile(Inventory&);
};

#endif

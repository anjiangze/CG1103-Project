#include "batch.h"

/*
Description: This file contains the basic manipulations of the object which will be used in the batch processing. The Inventory class will use these
functions for batch processing.
coder: Nicholas,Jiangze
*/
Command::Command(string time, string detail, string name,string category,int barcode, double price, string manufacturer,int numstock,int numsold)
{
	_time=time;
	_detail=detail;
	_name=name;
	_category=category;
	_barcode=barcode;
	_price=price;
	_manufacturer=manufacturer;
	_numstock=numstock;
	_numsold=numsold;
}


int Command::getBarcode()
{
	return _barcode;
}
int Command::getnumstock()
{
	return _numstock;
}
int Command::getnumsold()
{
	return _numsold;
}

double Command::getprice()
{
	return _price;
}
string Command::getname()
{
	return _name;
}
string Command::getcategory()
{
	return _category;
}
string Command::getmanufacturer()
{
	return _manufacturer;
}
string Command::getdetail()
{
	return _detail;
}

string Command::gettime()
{
	return _time;

}